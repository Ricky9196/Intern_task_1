# E-Commerce Product Landing Page

This is a responsive e-commerce landing page built using HTML, CSS, and JavaScript.

## Features

- Responsive design
- Product showcase
- Navigation between pages
- Contact form with validation
- Mobile-friendly layout

## Pages

- Home (index.html)
- Products
- About
- Contact

## Technologies Used

HTML5  
CSS3  
JavaScript

## Deployment

You can deploy this project using:

- GitHub Pages
- Netlify
- Vercel

## Author

Student Web Development Project
