document.addEventListener("DOMContentLoaded", function(){

const form = document.getElementById("contactForm");

if(form){

form.addEventListener("submit", function(e){

e.preventDefault();

let name = document.getElementById("name").value;
let email = document.getElementById("email").value;
let message = document.getElementById("message").value;

let msg = document.getElementById("formMessage");

if(name === "" || email === "" || message === ""){

msg.textContent = "Please fill all fields";
msg.style.color = "red";

}else{

msg.textContent = "Message sent successfully!";
msg.style.color = "green";

form.reset();

}

});

}

});